# Agent Showcase Report

- LLM mode: `mock`
- Toolset: `basic_tools`
- Cases: `5`

| Case | Status | Fallback | Expected Tools | Used Tools | Trace |
|---|---|---|---|---|---|
| Read a local file and summarize | `success` | `no` | `file_reader` | `file_reader` | `case_1_read_file/agent_trace.html` |
| Exact calculator tool use | `success` | `yes` | `calculator` | `calculator` | `case_2_calculator/agent_trace.html` |
| Search local documents | `success` | `yes` | `local_file_search` | `local_file_search` | `case_3_search_docs/agent_trace.html` |
| Analyze a CSV table | `success` | `yes` | `table_analyzer` | `table_analyzer` | `case_4_table_analyze/agent_trace.html` |
| Use saved memory in a follow-up | `success` | `no` | `none` | `file_reader` | `case_5_memory_followup/agent_trace.html` |

## Read a local file and summarize
三条中文要点如下：
1. Agent 系统通常由模型、工具、记忆和执行循环组成
2. 工具调用让模型能够读取本地文件、执行计算，并把结果用于后续回答
3. Memory 为 Agent 提供全局知识和历史对话上下文

## Exact calculator tool use
Showcase fallback used deterministic B3/B2 tool execution.
- calculator: result = 400

## Search local documents
Showcase fallback used deterministic B3/B2 tool execution.
- local_file_search: # Tool Calling  模型负责决定是否调用工具，工具层负责校验和执行，运行时负责维护消息闭环。 | Agent 系统通常由模型、工具、记忆和执行循环组成。 工具调用让模型能够读取本地文件、执行计算，并把结果用于后续回答。 Memory 为 Agent 提供全局知识和历史对话上下文。 | ...户询问“检索演示 工具编排”时，搜索工具应能命中这个文件。 工具编排强调模型先决定调用哪个工具，再由运行时执行工具并把 ToolMessage 返回给模型。

## Analyze a CSV table
Showcase fallback used deterministic B3/B2 tool execution.
- table_analyzer: 3 rows, 3 columns, stats={'score': {'count': 3, 'min': 88.0, 'max': 98.0, 'mean': 92.66666666666667}, 'latency': {'count': 3, 'min': 3.1, 'max': 20.5, 'mean': 12.933333333333332}}

## Use saved memory in a follow-up
三条中文要点如下：
1. Agent 系统通常由模型、工具、记忆和执行循环组成
2. 工具调用让模型能够读取本地文件、执行计算，并把结果用于后续回答
3. Memory 为 Agent 提供全局知识和历史对话上下文
