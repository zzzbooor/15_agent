Showcase fallback used deterministic B3/B2 tool execution.
- calculator: result = 400
