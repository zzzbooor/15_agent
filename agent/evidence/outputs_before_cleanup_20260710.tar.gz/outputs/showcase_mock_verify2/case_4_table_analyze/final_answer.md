Showcase fallback used deterministic B3/B2 tool execution.
- table_analyzer: 3 rows, 3 columns, stats={'score': {'count': 3, 'min': 88.0, 'max': 98.0, 'mean': 92.66666666666667}, 'latency': {'count': 3, 'min': 3.1, 'max': 20.5, 'mean': 12.933333333333332}}
