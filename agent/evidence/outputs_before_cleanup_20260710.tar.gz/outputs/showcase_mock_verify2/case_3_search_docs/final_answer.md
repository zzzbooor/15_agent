Showcase fallback used deterministic B3/B2 tool execution.
- local_file_search: # Tool Calling  模型负责决定是否调用工具，工具层负责校验和执行，运行时负责维护消息闭环。 | Agent 系统通常由模型、工具、记忆和执行循环组成。 工具调用让模型能够读取本地文件、执行计算，并把结果用于后续回答。 Memory 为 Agent 提供全局知识和历史对话上下文。 | ...户询问“检索演示 工具编排”时，搜索工具应能命中这个文件。 工具编排强调模型先决定调用哪个工具，再由运行时执行工具并把 ToolMessage 返回给模型。
