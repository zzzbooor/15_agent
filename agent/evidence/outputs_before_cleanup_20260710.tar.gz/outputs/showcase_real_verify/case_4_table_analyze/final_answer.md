表格 tables/results.csv 包含 3 行数据和 3 列（task、score、latency）。

主要数值统计：
- score 列：最小值 88.0，最大值 98.0，平均值 92.67
- latency 列：最小值 3.1，最大值 20.5，平均值 12.93

具体数据：
1. read_file: score=92, latency=15.2
2. calculate: score=98, latency=3.1
3. search: score=88, latency=20.5
