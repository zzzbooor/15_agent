# Agent Showcase Report

- LLM mode: `prompt_json`
- Toolset: `basic_tools`
- Cases: `5`

| Case | Status | Expected Tools | Used Tools | Trace |
|---|---|---|---|---|
| Read a local file and summarize | `success` | `file_reader` | `none` | `case_1_read_file/agent_trace.html` |
| Exact calculator tool use | `llm_parse_error` | `calculator` | `none` | `case_2_calculator/agent_trace.html` |
| Search local documents | `llm_parse_error` | `local_file_search` | `none` | `case_3_search_docs/agent_trace.html` |
| Analyze a CSV table | `success` | `table_analyzer` | `table_analyzer` | `case_4_table_analyze/agent_trace.html` |
| Use saved memory in a follow-up | `success` | `none` | `none` | `case_5_memory_followup/agent_trace.html` |

## Read a local file and summarize
1. Agent 系统由模型、工具、记忆和执行循环四个核心组件构成，模型负责决策，工具负责执行，记忆提供上下文，执行循环负责协调各部分协同工作。

## Exact calculator tool use


## Search local documents


## Analyze a CSV table
表格 tables/results.csv 包含 3 行数据和 3 列（task、score、latency）。

主要数值统计：
- score 列：最小值 88.0，最大值 98.0，平均值 92.67
- latency 列：最小值 3.1，最大值 20.5，平均值 12.93

具体数据：
1. read_file: score=92, latency=15.2
2. calculate: score=98, latency=3.1
3. search: score=88, latency=20.5

## Use saved memory in a follow-up
根据上一次保存的记忆（mem_conversation_showcase_01_case_1_read_file），Agent 系统由以下模块配合完成任务：

1. **模型（Model）**：负责决策，根据任务需求做出判断和选择。
2. **工具（Tools）**：负责执行，提供具体的功能（如文件读取、计算等）来完成任务。
3. **记忆（Memory）**：提供上下文，保存历史对话和任务信息，帮助系统保持状态。
4. **执行循环（Execution Loop）**：负责协调各部分协同工作，确保模型、工具和记忆之间的信息流畅传递。

这四个核心组件共同协作，使 Agent 能够自主地规划、执行和反思任务。
