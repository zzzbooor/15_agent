# Agent Showcase Report

- LLM mode: `mock`
- Toolset: `basic_tools`
- Cases: `5`

| Case | Status | Expected Tools | Used Tools | Trace |
|---|---|---|---|---|
| Read a local file and summarize | `success` | `file_reader` | `file_reader` | `case_1_read_file/agent_trace.html` |
| Exact calculator tool use | `success` | `calculator` | `file_reader` | `case_2_calculator/agent_trace.html` |
| Search local documents | `success` | `local_file_search` | `file_reader` | `case_3_search_docs/agent_trace.html` |
| Analyze a CSV table | `success` | `table_analyzer` | `file_reader` | `case_4_table_analyze/agent_trace.html` |
| Use saved memory in a follow-up | `success` | `none` | `file_reader` | `case_5_memory_followup/agent_trace.html` |

## Read a local file and summarize
三条中文要点如下：
1. Agent 系统通常由模型、工具、记忆和执行循环组成
2. 工具调用让模型能够读取本地文件、执行计算，并把结果用于后续回答
3. Memory 为 Agent 提供全局知识和历史对话上下文

## Exact calculator tool use
三条中文要点如下：
1. Agent 系统通常由模型、工具、记忆和执行循环组成
2. 工具调用让模型能够读取本地文件、执行计算，并把结果用于后续回答
3. Memory 为 Agent 提供全局知识和历史对话上下文

## Search local documents
三条中文要点如下：
1. Agent 系统通常由模型、工具、记忆和执行循环组成
2. 工具调用让模型能够读取本地文件、执行计算，并把结果用于后续回答
3. Memory 为 Agent 提供全局知识和历史对话上下文

## Analyze a CSV table
三条中文要点如下：
1. Agent 系统通常由模型、工具、记忆和执行循环组成
2. 工具调用让模型能够读取本地文件、执行计算，并把结果用于后续回答
3. Memory 为 Agent 提供全局知识和历史对话上下文

## Use saved memory in a follow-up
三条中文要点如下：
1. Agent 系统通常由模型、工具、记忆和执行循环组成
2. 工具调用让模型能够读取本地文件、执行计算，并把结果用于后续回答
3. Memory 为 Agent 提供全局知识和历史对话上下文
