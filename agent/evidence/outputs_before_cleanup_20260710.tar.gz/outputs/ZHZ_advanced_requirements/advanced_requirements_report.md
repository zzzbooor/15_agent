# Advanced Requirements Report

## B1
- Done: multi-turn input, repeated tool-call loop, checkpoint resume, batch tasks, deterministic history compression, prompt-template switching.
- Evidence: `B1_ADVANCED_USAGE.md`, `data/b1_advanced/`, and `b1_agent_runtime.py`.

## B2
- Done: enhanced local search, sandboxed code execution, composite skills, error codes, and resource limits.
- Evidence: `skills/local_file_search.py`, `skills/code_executor.py`, `skills/composite_skills.py`, `b2_run_skill.py`.

## B3
- Auto schema generated from Python functions: `8` tools.
- Retry/cache/statistics report: `4` successes, cache hits `1`.
- Schema-description comparison variants: `full_description, name_only`.

## B4
- Plan-and-Execute produced `2` tool calls and `2` ToolMessages.
- Tool-binding/model comparison profiles: `default`.

## B5
- Keyword memory search results: `3`.
- Vector memory search results: `3`.
- Memory update action: `appended`.
- Bad-memory analysis rows: `3`.

## Output Files
- `b3_advanced_batch_tool_calls.json`
- `b3_advanced_tool_messages.json`
- `b3_auto_schema_from_python.json`
- `b3_schema_description_comparison.json`
- `b3_tool_cache.json`
- `b3_tool_call_stats.json`
- `b4_model_and_tool_binding_comparison.json`
- `b4_plan_execute_report.json`
- `b5_bad_memory_effect_analysis.json`
- `b5_keyword_search.json`
- `b5_memory_update_result.json`
- `b5_vector_search.json`
- `tool_messages.json`
- `tool_schema_report.json`
- `tools_schema.json`
