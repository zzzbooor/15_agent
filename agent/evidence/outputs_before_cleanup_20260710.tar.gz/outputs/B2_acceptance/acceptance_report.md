# B2 Acceptance Report

- Status: success
- Passed: 24/24
- Failed: 0

| Group | Case | Skill | Result |
|---|---|---|---|
| contract | catalog_and_tools_config | - | PASS |
| basic | calculator_normal | calculator | PASS |
| basic | file_reader_normal | file_reader | PASS |
| basic | local_file_search_normal | local_file_search | PASS |
| basic | table_analyzer_normal | table_analyzer | PASS |
| basic | format_converter_normal | format_converter | PASS |
| basic | calculator_error | calculator | PASS |
| basic | file_reader_error | file_reader | PASS |
| basic | local_file_search_error | local_file_search | PASS |
| basic | table_analyzer_error | table_analyzer | PASS |
| basic | format_converter_error | format_converter | PASS |
| contract | missing_required_parameter | calculator | PASS |
| limits | search_query_budget | local_file_search | PASS |
| limits | search_index_token_budget | local_file_search | PASS |
| advanced | read_and_convert_success | read_and_convert | PASS |
| advanced | analyze_and_convert_success | analyze_and_convert | PASS |
| advanced | composite_cause_error | read_and_convert | PASS |
| security | restricted_math_success | code_executor | PASS |
| security | forbidden_import | code_executor | PASS |
| security | builtins_escape | code_executor | PASS |
| security | getattr_escape | code_executor | PASS |
| security | dunder_escape | code_executor | PASS |
| security | infinite_loop | code_executor | PASS |
| limits | loop_iteration_budget | code_executor | PASS |
