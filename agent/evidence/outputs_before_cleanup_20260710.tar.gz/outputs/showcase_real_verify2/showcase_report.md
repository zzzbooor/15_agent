# Agent Showcase Report

- LLM mode: `prompt_json`
- Toolset: `basic_tools`
- Cases: `5`

| Case | Status | Fallback | Expected Tools | Used Tools | Trace |
|---|---|---|---|---|---|
| Read a local file and summarize | `success` | `yes` | `file_reader` | `file_reader` | `case_1_read_file/agent_trace.html` |
| Exact calculator tool use | `success` | `yes` | `calculator` | `calculator` | `case_2_calculator/agent_trace.html` |
| Search local documents | `success` | `yes` | `local_file_search` | `local_file_search` | `case_3_search_docs/agent_trace.html` |
| Analyze a CSV table | `success` | `no` | `table_analyzer` | `table_analyzer` | `case_4_table_analyze/agent_trace.html` |
| Use saved memory in a follow-up | `success` | `no` | `none` | `none` | `case_5_memory_followup/agent_trace.html` |

## Read a local file and summarize
Showcase fallback used deterministic B3/B2 tool execution.
- file_reader: Agent 系统通常由模型、工具、记忆和执行循环组成；工具调用让模型能够读取本地文件、执行计算，并把结果用于后续回答；Memory 为 Agent 提供全局知识和历史对话上下文

## Exact calculator tool use
Showcase fallback used deterministic B3/B2 tool execution.
- calculator: result = 400

## Search local documents
Showcase fallback used deterministic B3/B2 tool execution.
- local_file_search: # Tool Calling  模型负责决定是否调用工具，工具层负责校验和执行，运行时负责维护消息闭环。 | Agent 系统通常由模型、工具、记忆和执行循环组成。 工具调用让模型能够读取本地文件、执行计算，并把结果用于后续回答。 Memory 为 Agent 提供全局知识和历史对话上下文。 | ...户询问“检索演示 工具编排”时，搜索工具应能命中这个文件。 工具编排强调模型先决定调用哪个工具，再由运行时执行工具并把 ToolMessage 返回给模型。

## Analyze a CSV table
表格 tables/results.csv 包含 3 行数据和 3 列（task、score、latency）。

主要数值统计：
- score 列：最小值 88.0，最大值 98.0，平均值 92.67
- latency 列：最小值 3.1，最大值 20.5，平均值 12.93

具体数据：
1. read_file: score=92, latency=15.2
2. calculate: score=98, latency=3.1
3. search: score=88, latency=20.5

## Use saved memory in a follow-up
根据记忆中的信息，这个 Agent 系统由以下模块配合完成任务：

1. **模型（Model）**：负责决策，根据任务需求决定调用哪些工具。

2. **工具（Tools）**：负责执行具体操作，包括读取本地文件、执行计算等，并将结果返回给模型用于后续回答。

3. **记忆（Memory）**：为 Agent 提供全局知识和历史对话上下文，帮助系统保持连续性和一致性。

4. **执行循环（Execution Loop）**：负责协调模型、工具和记忆之间的协作，管理整个 Agent 的运行流程。

这些模块共同工作，使 Agent 能够理解用户请求、调用适当工具、利用历史记忆，并生成连贯的回复。
