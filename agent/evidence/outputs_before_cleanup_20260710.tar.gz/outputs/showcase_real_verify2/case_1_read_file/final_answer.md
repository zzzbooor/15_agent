Showcase fallback used deterministic B3/B2 tool execution.
- file_reader: Agent 系统通常由模型、工具、记忆和执行循环组成；工具调用让模型能够读取本地文件、执行计算，并把结果用于后续回答；Memory 为 Agent 提供全局知识和历史对话上下文
